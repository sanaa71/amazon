# Amazon-Landing-page-using-htmal-css
I make a Amazon Landing page using htmal &amp; css
